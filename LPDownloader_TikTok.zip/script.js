/* OPENING */
setTimeout(()=>{opening.style.display="none";app.style.display="block";},7000);

/* MODAL FUNCTIONS */
function showModal(type){
  if(type==='desc') descModal.style.display='block';
  if(type==='update') updateModal.style.display='block';
}
function closeModal(id){
  document.getElementById(id).style.display='none';
}

/* DOWNLOAD VIDEO */
async function getVideo(){
const url=urlInput.value.trim();
const format=formatSelect.value;
const quality=qualitySelect.value;
const btn=document.getElementById("btn");

if(!url){alert("Masukin link TikTok dulu!");return;}

btn.innerText="AMBIL DATA...";
btn.disabled=true;

try{
const r=await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`);
const j=await r.json();
if(!j.data) throw 0;

let videoLink = quality==="hd" ? (j.data.hdplay || j.data.play) : j.data.play;
let finalLink = format==="mp3" ? j.data.music : videoLink;

/* PREVIEW */
if(format==="mp4"){video.src=finalLink;preview.style.display="block";}
else{preview.style.display="none";}
title.innerText=j.data.title || "TikTok Video";

/* RESULT */
dl.href=finalLink;
dl.setAttribute("download",""); // penting agar APK bisa download
result.style.display="block";
btn.innerText="SELESAI";

}catch{
alert("Gagal ambil video");
btn.innerText="PROSES";
}
btn.disabled=false;
}

/* ELEMENT SHORTCUT */
const urlInput=document.getElementById("url");
const formatSelect=document.getElementById("format");
const qualitySelect=document.getElementById("quality");
const preview=document.getElementById("preview");
const video=document.getElementById("video");
const title=document.getElementById("title");
const dl=document.getElementById("dl");
const result=document.getElementById("result");
const descModal=document.getElementById("descModal");
const updateModal=document.getElementById("updateModal");